module.exports = {

  // Secret key for JWT signing and encryption
  secret: 'super secret passphrase',

    // Database connection information
  // database: 'mongodb://scdev:abc123@ds151612.mlab.com:51612/sellercapital_dev',
  database: 'mongodb://scdev:abc123@ds023213.mlab.com:23213/scdev',
  //database: 'mongodb://localhost:27017/scdev',
  // database: 'mongodb://sale:abc123@ds239412.mlab.com:39412/salercapital',

    // Setting port for server
  port: 9001,

    // Configuring Mailgun API for sending transactional email
  mailgun_priv_key: 'mailgun private key here',

    // Configuring Mailgun domain for sending transactional email
  mailgun_domain: 'mailgun domain here',

    // Mailchimp API key
    mailchimpApiKey: 'mailchimp api key here',

    // SendGrid API key
    sendgridApiKey: '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',

    // Amazon Access Keys
    MWS_KEY: 'AKIAIEGT53RIXYQUCTPQ',

    // Amazon Secret Keys
    MWS_SECRET: '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',
  // Stripe API key
  stripeApiKey: 'stripe api key goes here',
  // necessary in order to run tests in parallel of the main app
  test_port: 9002,
  test_db: 'mern-starter-test',
  test_env: 'test'
};
