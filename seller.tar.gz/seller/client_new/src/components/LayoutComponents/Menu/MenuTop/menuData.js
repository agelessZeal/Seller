export default [
  {
    title: 'Dashboard',
    key: 'dashboardAlpha',
    url: '/dashboard',
    icon: 'icmn icmn-stack',
  },
  {
    title: 'Empty Page',
    key: 'empty',
    url: '/empty',
    icon: 'icmn icmn-books',
  },
]
